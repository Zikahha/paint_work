import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Point;
import java.awt.geom.Line2D;

// 该类可以根据选择操作操作的不同绘制不同种类的图
public class MultiShape extends Shape {
    private int x2, y2;
    private boolean isSelected = false;
    
    public MultiShape(int x1, int y1, int x2, int y2) {
        super(x1, y1);
        this.x2 = x2;
        this.y2 = y2;
    }
    
    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
    
    public boolean isSelected() {
        return isSelected;
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D p = (Graphics2D) g;
        p.setColor(this.selectedColor);
        if (this.isSelected) {
            p.setStroke(new BasicStroke(this.width * 2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, new float[]{10f}, 0.0f));
        } else {
            p.setStroke(new BasicStroke(this.width));
        }
        this.innerDraw(p);
    }

    private void swap() {
        // 保证x1<=x2,y1<=y2，在绘制矩形、圆时需要
        if (x1 > x2) {
            int tmp = x1;
            x1 = x2;
            x2 = tmp;
        }
        if (y1 > y2) {
            int tmp = y1;
            y1 = y2;
            y2 = tmp;
        }
    }

    private void innerDraw(Graphics p) {
        switch (this.operation) {
            case "铅笔":
            case "直线":
                p.drawLine(x1, y1, x2, y2);
                break;
            case "矩形":
                this.swap();
                p.drawRect(x1, y1, x2 - x1, y2 - y1);
                break;
            case "圆":
                this.swap();
                p.drawOval(x1, y1, x2 - x1, y2 - y1);
                break;
        }
    }
    public boolean contains(Point p) {
        switch (operation) {
            case "铅笔":
                // 铅笔不支持 contains() 方法
                return false;
            case "直线":
                // 直线的 contains() 方法可以根据点到直线的距离是否小于一定阈值来判断点是否在直线上
                double dist = Line2D.ptSegDist(x1, y1, x2, y2, p.getX(), p.getY());
                return dist <= width / 2.0;
            case "矩形":
                // 矩形的 contains() 方法可以根据点是否在矩形内部来判断
                return p.getX() >= x1 && p.getX() <= x2 && p.getY() >= y1 && p.getY() <= y2;
            case "圆":
                // 圆的 contains() 方法可以根据点到圆心的距离是否小于半径来判断点是否在圆内
                double centerX = (x1 + x2) / 2.0;
                double centerY = (y1 + y2) / 2.0;
                double radius = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)) / 2.0;
                double distToCenter = Math.sqrt(Math.pow(p.getX() - centerX, 2) + Math.pow(p.getY() - centerY, 2));
                return distToCenter <= radius + width / 2.0;
            default:
                return false;
        }
    }
}
