public class Window {
    public static void main(String[] args) {
        // 获取画图区域实例
        Drawboard.getInstance();
    }
}
