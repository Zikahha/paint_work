import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.event.MouseInputAdapter;

public class MoveableShape extends Shape {
    private Point startPoint;
    private boolean isSelected;

    public MoveableShape(int x1, int y1) {
        super(x1, y1);
        isSelected = false;
    }

    public MoveableShape(int x1, int y1, Color customColor) {
        super(x1, y1, customColor);
        isSelected = false;
    }

    @Override
    public void draw(Graphics g) {
        // 绘制图形
    }

    @Override
    public void refresh() {
        isSelected = false;
        super.refresh();
    }

    public boolean contains(Point p) {
        // 判断点是否在图形内部
        return false;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void move(int deltaX, int deltaY) {
        // 移动图形
        x1 += deltaX;
        y1 += deltaY;
    }

    public MouseInputAdapter getMouseAdapter() {
        // 返回鼠标监听器
        return new MouseInputAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                startPoint = e.getPoint();
                if (contains(startPoint)) {
                    setSelected(true);
                }
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                if (isSelected()) {
                    setSelected(false);
                }
            }

            @Override
            public void mouseDragged(java.awt.event.MouseEvent e) {
                if (isSelected()) {
                    int deltaX = e.getX() - startPoint.x;
                    int deltaY = e.getY() - startPoint.y;
                    move(deltaX, deltaY);
                    startPoint = e.getPoint();
                    // 更新绘图板
                }
            }
        };
    }
}